﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Observable.cs" company="OxyPlot">
//   Copyright (c) 2014 OxyPlot contributors
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace WpfExamples
{
    public class Observable : PropertyTools.Observable
    {
    }
}