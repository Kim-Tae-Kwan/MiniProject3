﻿namespace MathBlockDemo
{
    using WpfExamples;

    [Example(null, "MathBlock control")]
    public partial class MainWindow
    {
        public MainWindow()
        {
            this.InitializeComponent();
        }
    }
}